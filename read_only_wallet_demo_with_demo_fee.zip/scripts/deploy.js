const hre=require("hardhat");
async function main(){
 const [owner]=await hre.ethers.getSigners();
 const V=await hre.ethers.getContractFactory("OwnerVault");
 const v=await V.deploy(owner.address); await v.waitForDeployment();
 const T=await hre.ethers.getContractFactory("DemoToken");
 const t=await T.deploy(); await t.waitForDeployment();
 console.log("OWNER:",owner.address);
 console.log("VAULT:",await v.getAddress());
 console.log("TOKEN:",await t.getAddress());
}
main().catch(e=>{console.error(e);process.exitCode=1});