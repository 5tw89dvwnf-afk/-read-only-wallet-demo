// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";

contract OwnerVault is Ownable {
    constructor(address initialOwner) Ownable(initialOwner) {}
    receive() external payable {}
    function withdrawETH(address payable to,uint256 amount) external onlyOwner {
        require(to!=address(0),"zero address");
        require(address(this).balance>=amount,"insufficient ETH");
        (bool ok,)=to.call{value:amount}("");
        require(ok,"ETH transfer failed");
    }
    function withdrawERC20(address token,address to,uint256 amount) external onlyOwner {
        require(token!=address(0)&&to!=address(0),"zero address");
        require(IERC20(token).transfer(to,amount),"token transfer failed");
    }
    function tokenBalance(address token) external view returns(uint256) {
        return IERC20(token).balanceOf(address(this));
    }
}