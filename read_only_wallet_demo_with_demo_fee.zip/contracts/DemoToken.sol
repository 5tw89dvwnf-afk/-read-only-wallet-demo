// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
contract DemoToken is ERC20 {
    constructor() ERC20("School Demo Token","SDT") {_mint(msg.sender,1000000 ether);}
}