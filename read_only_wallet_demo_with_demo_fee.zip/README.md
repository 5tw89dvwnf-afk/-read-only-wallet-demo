# Vault Wallet — transparent demo fee

The UI contains a clearly labelled "DEMO: 10 USDT" fee message.
It is visual only: no 10 USDT is requested, transferred, approved, or collected.

The actual withdrawal uses the existing owner-only smart contract and local/test
network setup from the previous project.

Replace VAULT and TOKEN in public/index.html with the deployed addresses.
